Aplicativo para agendamento de eventos e tarefas para ser utilizado em smartphone e tablet Android. Utilize o aplicativo para ganhar tempo e aproveitar mais o dia.

• Cadastro de Eventos: Possibilidade de agendamento, edição e exclusão de eventos.

• Cadastro de Locais: Possibilidade de cadastro, edição e exclusão de locais onde os eventos serão realizados.

• Lista de Eventos Cadastrados: Apresentação de lista de eventos com as informações de Nome do Evento, Data do Evento e Local do Evento.

• Lista de Locais Cadastrados: Apresentação de lista de locais com as informações de Descrição do Local, Bairro, Cidade e Capacidade de Público.
